var searchData=
[
  ['bessel_5f1841',['BESSEL_1841',['../_m_g_r_s_8cpp.html#a6c50d2e5fc682d8215048d7bd3883ef5',1,'MGRS.cpp']]],
  ['bessel_5f1841_5fnamibia',['BESSEL_1841_NAMIBIA',['../_m_g_r_s_8cpp.html#a5e209b65290b189ca6fb28318ff705d5',1,'MGRS.cpp']]]
];
