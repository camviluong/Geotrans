var searchData=
[
  ['cassini',['cassini',['../class_m_s_p_1_1_c_c_s_1_1_coordinate_type.html#a418b669819e988d0cb43c506beffd8eba584526a1b4c0f93c9ae4cbe15ffbecd3',1,'MSP::CCS::CoordinateType']]],
  ['cylindricalequalarea',['cylindricalEqualArea',['../class_m_s_p_1_1_c_c_s_1_1_coordinate_type.html#a418b669819e988d0cb43c506beffd8ebabeb826c1817557f071296dc14d86c399',1,'MSP::CCS::CoordinateType']]]
];
