var searchData=
[
  ['validdatum',['validDatum',['../class_m_s_p_1_1_c_c_s_1_1_datum_library_implementation.html#a176f1f2bacfe4b4b36621eba6df90b2c',1,'MSP::CCS::DatumLibraryImplementation::validDatum()'],['../class_m_s_p_1_1_c_c_s_1_1_datum_library.html#a48439d010aac920e40aaae7335b36799',1,'MSP::CCS::DatumLibrary::validDatum()']]],
  ['vandergrinten',['vanDerGrinten',['../class_m_s_p_1_1_c_c_s_1_1_coordinate_type.html#a418b669819e988d0cb43c506beffd8eba516a231aca70602c7eee63b250cd7772',1,'MSP::CCS::CoordinateType::vanDerGrinten()'],['../class_m_s_p_1_1_c_c_s_1_1_van_der_grinten.html#a8944c33f713f2d1573d00449be4150f3',1,'MSP::CCS::VanDerGrinten::VanDerGrinten(double ellipsoidSemiMajorAxis, double ellipsoidFlattening, double centralMeridian, double falseEasting, double falseNorthing)'],['../class_m_s_p_1_1_c_c_s_1_1_van_der_grinten.html#ab562eeba421997a9b18295c978263898',1,'MSP::CCS::VanDerGrinten::VanDerGrinten(const VanDerGrinten &amp;v)']]],
  ['vandergrinten',['VanDerGrinten',['../class_m_s_p_1_1_c_c_s_1_1_van_der_grinten.html',1,'MSP::CCS']]],
  ['vandergrinten_2ecpp',['VanDerGrinten.cpp',['../_van_der_grinten_8cpp.html',1,'']]],
  ['vandergrinten_2eh',['VanDerGrinten.h',['../_van_der_grinten_8h.html',1,'']]]
];
