var searchData=
[
  ['quad',['QUAD',['../_g_e_o_r_e_f_8cpp.html#af040624ca5fe47dee90d874726124a77',1,'GEOREF.cpp']]]
];
